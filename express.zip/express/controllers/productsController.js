
//список доступных продуктов
let products = [
    {id: 1, name: "телевизор", price:40},
    {id: 2, name: "холодильник", price:50},
]

//прочитать все продукты
exports.index = function (request, response) {
    return response.send(200).json(products);
};


// CRUD